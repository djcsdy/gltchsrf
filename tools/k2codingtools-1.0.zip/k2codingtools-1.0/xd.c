/* xd

  Prints a Hexdump of Commodore Objects
  by A.Kaesmacher
  written since 25.10.2002
  
  TODO: parse arguments better, repair pipe
    
  Version 1.0
     
  Compile-Hints
  
  BUGS
  Printable Characters are host-system dependant  
*/	

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../8bitmem.h"
#include "../dnc.h"

/*prototypes*/
char printz(unsigned char);

/*global vars*/

int main(int argc, char ** argv)
{
	FILE * inf;
	FILE * dncf;
	int pc,i;
	int t,rt,ort;
	int myarg=0;
	int tmp;
	char * ptr;
	char dncname[100];
	
	DNC_Init(0);
	
	if(argc==2) {
	  /* Now strip of all after . and attach dnc */
	  ptr=strrchr(argv[1],'.');
	  if(ptr==NULL) {
	    tmp=strlen(argv[1]);
	  }
	  else {
	    tmp=ptr-argv[1];
	  }
	  strncpy(dncname,argv[1],tmp);
	  dncname[tmp+0]='.';
	  dncname[tmp+1]='d';
	  dncname[tmp+2]='n';
	  dncname[tmp+3]='c';
	  dncname[tmp+4]=0;

	  dncf=fopen(dncname,"r");
	  if(dncf==NULL) ;
	  else {
	    DNC_SetFile(dncf);
	    DNC_Read(dncf);
	    fclose(dncf);
	  }
	}
	
	if(argc>1) {
	  if(strcmp(argv[1],"-d")==0) {
	    dncf=fopen(argv[2],"r");
	    DNC_SetFile(dncf);
	    DNC_Read(dncf);
	    fclose(dncf);
	    myarg+=2;
	  }
	}
	
	if(argc==myarg+2)
	  inf=fopen(argv[myarg+1],"rb");
	else
	  inf=stdin;

	initmem();

	if(inf==NULL) {
	  fprintf(stderr,"Error: Can't open %s\n",argv[myarg+1]);
	  exit(1);
	}

	tmp=readmem(inf);

	if(tmp==-1) {
	  fprintf(stderr,"Error: Can't read %s\n",argv[myarg+1]);
	  exit(1);
	}

        fprintf(stderr,"$%04X-$%04X\n",pc_start,pc_end);
        	
	rt=0;	
	for(i=pc_start;i<pc_end;i++) {
	  if(rt==0) fprintf(stdout,"%04x",i);
	  if(DNCBuffer[i]==0) fprintf(stdout," %02x",mem[i]);
	  else {
	    fprintf(stdout," ");
	    if((DNCBuffer[i]&0xf0)==0xf0) fprintf(stdout,"?");
	    else fprintf(stdout,"%x",mem[i]>>4);
	    if((DNCBuffer[i]&0x0f)==0x0f) fprintf(stdout,"?");
	    else fprintf(stdout,"%x",mem[i]&0x0f);
	  }
	  rt++;
	  if(rt==16) {
	    rt=0;
	    fprintf(stdout," '");
	    for(t=i-15;t<=i;t++) {
	      if(DNCBuffer[t]!=0) fprintf(stdout,"?");
	      else
		fprintf(stdout,"%c",printz(mem[t]));
	    }
	    fprintf(stdout,"'\n");
	  }
	}
	ort=rt;
	while(rt<16)
	{
	 rt++;
	 fprintf(stdout,"   ");
	}
	
	if(ort) fprintf(stdout," '");
	for(t=i-ort;t<i;t++) {
          if(DNCBuffer[t]!=0) fprintf(stdout,"?");
          else
	    fprintf(stdout,"%c",printz(mem[t]));
        }
	if(ort) fprintf(stdout,"'");	
	
	fprintf(stdout,"\n");
	
	exitmem();
	DNC_Exit();
	if(inf!=stdin) fclose(inf);
	return 0;
}

char printz(unsigned char mem)
{
  if(isalnum(mem)||(mem>=0x20 && mem<0x40)) return(mem);
  if(mem<27) return(mem+0x40); 
  return(0x2e);
}



