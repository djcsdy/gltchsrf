/* dncsprite

  An Spritefile and a dnc files gets feed in.
  The Object will be changed, so that it is shorter
  when packed via huffman-methods

  dncsprite spritefile dncfile
    
  by A.Kaesmacher
  written on 12.09.2002
  
  V1.0 AK 15.09.2002
    If only one arg, inf=stdin, outf=stdout
      
  Needs dnc.o and 8bitmem.o
  		
  BUGS
  
*/	

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../8bitmem.h"
#include "../dnc.h"

/*prototypes*/

/*global vars*/

int main(int argc, char ** argv)
{
	FILE * dncf;
	FILE * objf;
	char * dncname;
	char * objname;
		
	int tmp;
	int i;
	int lastarg;
	word pc;

        int anzspr;
        int counter;

	if(argc<2) {
	  fprintf(stderr,"dncsprite [objfile] dncfile\n");
	  exit(1);
	}
	lastarg=argc-1;	
	dncname=argv[lastarg];
	
	if(argc==2) objname="std"; 
	else objname=argv[1];

/* read dnc,mem */
	
	DNC_Init(0);
	
	dncf=fopen(dncname,"r");
	if(dncf==NULL) {
	  fprintf(stderr,"Warning: Can't open dnc file %s\n",dncname);
	}
	else {
	  DNC_SetFile(dncf);
	  tmp=DNC_Read(dncf);
	  if(tmp==-1) {
	    fprintf(stderr,"Error: Can't read dnc file %s\n",dncname);
	    DNC_Exit();
	    exit(1);
	  }
	  fclose(dncf);
	}
	
	initmem();
	
	if(strcmp(objname,"std")==0) {
	  objf=stdin;
	}
	else {
	  objf=fopen(objname,"rb");
	}
	if(objf==NULL) {
	  fprintf(stderr,"Error: Can't open obj file %s\n",objname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}
	tmp=readmem(objf);
	if(tmp==-1) {
	  fprintf(stderr,"Error: Can't read obj file %s\n",objname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}
	if(strcmp(objname,"std")!=0) fclose(objf);
	
/* Do the actual Work */

// Check for pc_start at $40 addr
	if( (pc_start%0x40)!=0 ) {
	  fprintf(stderr,"Error: Not a valid load address:$%04x\n",pc_start);
	  exit(1);
	}
	fprintf(stderr,"Sprite start at $%04x\n",pc_start);

// Check for valid length	
	if( ((pc_end-pc_start)%0x40)!=0 ) {
	  fprintf(stderr,"Warning: Last Sprite is only partial defined\n");
	}
	fprintf(stderr,"Found %i Sprite-Blocks\n",(pc_end-pc_start)/0x40);
	
	counter=0;anzspr=0;
        for(pc=pc_start;pc<pc_end;pc++) {
	  if(counter==63) {
	    DNCBuffer[pc]=255;
	    anzspr++;
	  }
	  counter++;
	  if(counter==64) counter=0;          
        }
        
/* Some interesting Informations */
	fprintf(stderr,"Processed %i Sprites\n",anzspr);
	
/* Write dnc, mem */

/* We only need to write the memory to stdout (not file), 
because then we are a Part of a Pipeline */

	if(strcmp(objname,"std")==0) {
	  objf=stdout;
	  tmp=writemem(objf);
	}
	
	dncf=fopen(dncname,"w");
	if(dncf==NULL) {
	  fprintf(stderr,"Error: Can't open for write to dnc file %s\n",dncname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}
	pc_start=0;pc_end=0xffff; //to write all dncs!
	DNC_SetFile(dncf);
	tmp=DNC_Write(pc_start,pc_end);
	if(tmp==-1) {
	  fprintf(stderr,"Error: Can't write to dnc file %s\n",dncname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}
	// fclose(dncf);

	DNC_Exit();	
	exitmem();
	
	return 0;
}





