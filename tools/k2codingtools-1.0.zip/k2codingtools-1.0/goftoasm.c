/*
 goftoasm
 
 Filter to read in gofer-list, and spit out assembler code

*/

#include <stdio.h>

typedef unsigned char byte;
typedef unsigned short word;

int main(int argc, char *argv[] )
{
	int intmp,tmp;
	byte in,out;
	tmp=0;
        while(in!='[') {
          intmp=fgetc(stdin);
          if(intmp==EOF) return 1; //error: [ not found
          in=(byte)intmp;
        }
	while(in!=']') { 
	  intmp=fscanf(stdin,"%i",&in);
	  if(intmp==EOF) return 1; //error not a number
	  tmp=fprintf(stdout," .byte %i\n",in);
	  while(in!=','&&in!=']') {
	    intmp=fgetc(stdin);
            if(intmp==EOF) return 1; //error: 
	    in=(byte)intmp;
	  }
	}
	return 0;
}
