/* TODO:
   sourcecode cleanup
*/

/* K2LINK
	A Cross-Linker for Commodore Computer
	by A.Kaesmacher
	not copyrighted since 03.11.2000

        BUGFIX AK 03.01.2004
                Check if there are too many files
                Display which file leaves 64K
                  
	V1.9 AK 12.12.2003
		Each linked object-dnc file gets read in
		Better warnings
                		
	V1.8 AK 05.09.2003
		BUGFIX: No more Problems without -d switch
		
	V1.7 AK 13.08.2003
		Sorted Output, IMPLEMENTED BUG: Doesnt read DNC
		 
	V1.6 AK 27.05.2003
		Renamed to k2link
		
	V1.5 AK 16.11.2002
		Slightly improved cli-parsing..

	V1.4 AK 15.09.2002
		Now defaults to stdout,
		*** SINCE V1.4 USE -o outputfile ***
		
        V1.3 AK 11.09.2002
                Support for dnc files
                
	V1.2 AK 23.06.2002
		Memory Hole bug removed

	V1.1 AK 15.06.2002
		only 2 Arguments are required
		trailing zero bug removed
	
	This is a dumb linker ->	
	Just puts zeros between the objects
	Don't forget to run a Packer afterwards
	
	TODO:
	subroutines?

        SEVERE BUGS:
        Does not cope with files covering $FFFE-$FFFF
        
	BUGS:
	Does not support filenames from other file (-f)
	Does not support relocation of Objects (c64la should does this)
*/	

//#define DEBUG


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>

#include "../8bitmem.h"
#include "../dnc.h"

#define MAXFILES 255

/*prototypes*/

/*global vars*/

void usage()
{
	fprintf(stderr,"K2link V1.9\n");
	fprintf(stderr,"by A.Kaesmacher\n");
	fprintf(stderr,"Usage: K2LINK [-d dncfile] inputfiles.. [-o outputfile]\n");
	fprintf(stderr,"Need at last 1 Input file\n");
	return;
}

int main(int argc, char ** argv)
{
	unsigned int pc;
	unsigned int i;
	char * ptr;
	FILE *inf;
	FILE *outf;
// 	  unsigned char *outname;
	char outname[100];
	FILE *dncf;
	FILE *tdncf;	
	char dncname[100];
	char tdncname[100];
	int warn,error;
	
	int tmp;

	int endnc;

	int curpart;
	int namemapping[MAXFILES];
	int startaddr[MAXFILES];
	int endaddr[MAXFILES];
	int TagBuffer[65535];
	
	error=0;
	for(i=0;i<65535;i++) TagBuffer[i]=0;
			      
	strcpy(outname,"stdout");
	tmp=getopt(argc,argv,"d:o:h");
	while(tmp!=-1)
	{
	  switch(tmp)
	  {
	    case 'd': 
		endnc=1;
		strcpy(dncname,optarg);
	    	break;
	    case 'o':
	    	strcpy(outname,optarg);
	    	break;
	    case 'h':
	    case '?': usage();exit(1); break;
	    default:  usage();exit(1); break;
	  }
	  tmp=getopt(argc,argv,"d:o:h");
	}
	if(optind==argc) { usage();exit(1); }
#ifdef DEBUG
	if(endnc==1) printf("dncname=%s\n",dncname);
	printf("outname=%s\n",outname);
	
	for(tmp=optind;tmp<argc;tmp++) {
	  printf("arg: %s\n",argv[tmp]);
	}
//	return 0;
#endif

	if(initmem()==NULL) {
		fprintf(stderr,"\nError: Can't get enough Memory!\n");
		exit(1);
	}
	
//	if(endnc==1) {
	  if(DNC_Init(0xFF)==NULL) {	
		fprintf(stderr,"\nError: Can't get enough Memory!\n");
		exit(1);
//	  }
#ifdef DEBUG
	  printf("\nDNCFILL=%i\n",DNCBuffer[1000]);
#endif
//#ifdef LOADDNC
	if(endnc) {
	  dncf=fopen(dncname,"r");
	  if(dncf==NULL) {
	    fprintf(stderr,"\nWarning: Can't open dncfile %s\n",dncname);
	  }
	  else {
	    DNC_SetFile(dncf);
	    tmp=DNC_Read();
	    if(tmp==-1) {
	      fprintf(stderr,"\nWarning: Can't read dncfile %s\n",dncname);
	    }
	  }
	}
//#endif
#ifdef DEBUG
	  printf("\nDNCFILL=%i\n",DNCBuffer[8192]);
#endif

	}
	


	fprintf(stderr,"Input Files\n");
	curpart=0;
	
	//We should get rid of MAXFILES!
	if(argc-optind>MAXFILES)
	{
	  fprintf(stderr,"Too many Files!\n");exit(1);
	}
	
	for(i=optind;i<argc;i++) {
		
		curpart++;
		namemapping[curpart]=i;
		warn=0;
				
//Hmm, maybe I should rewrite k2link..

		inf=fopen(argv[i],"rb");
		if(inf==NULL) {
			fprintf(stderr,"\nError: Can't open input file:%s\n",argv[i]);
			exitmem();
			//if(endnc==1) 
			DNC_Exit();
			exit(1);
		}
		tmp=readla(inf);
		if(tmp==-1) {
			fprintf(stderr,"\nError: Can't read Loadaddress from file:%s\n",argv[i]);
			exitmem();
			//if(endnc==1)
			DNC_Exit();
			exit(1);
		}
		pc=tmp;
		startaddr[curpart]=pc;
//		fprintf(stderr,"Object: %-16s $%04X",argv[i],pc);
		
		if(pc<pc_start) pc_start=pc;
		
		while(1)
		{
			tmp=fgetc(inf);
			if(tmp==EOF) break;
			mem[pc]=tmp;
//			if(endnc==1) {
#ifdef DEBUG
//			  printf("\nDNC=%i\n",DNCBuffer[pc]);
#endif
			  if(TagBuffer[pc]!=warn) {
			    if(warn==0)
			    {
			     warn=TagBuffer[pc];
			     fprintf(stderr,"Error: %s overlaps %s from $%04X",argv[i],argv[namemapping[warn]],pc);
                             error++;
			    }
			    else
			    {
			     warn=0;
			     fprintf(stderr," to $%04X\n",pc-1);
			    }
			  }
			  TagBuffer[pc]=curpart;
			  DNCBuffer[pc]=0; 
//			}
			pc++;
		        if(pc>65535) { fprintf(stderr,"ERROR: %s leaves 64K\n",argv[i]);pc=0;error++;}
		}
		endaddr[curpart]=pc-1; 
//		fprintf(stderr," - $%04X\n",pc-1);
		
		if(pc>pc_end) pc_end=pc;
		
		fclose(inf);

	if(warn!=0) fprintf(stderr," to $%04X\n",pc-1);
	
//Now lets read the dnc-file, if possible
	if(endnc)
	{
	  /* Now strip of all after . and attach dnc */
	  ptr=strrchr(argv[i],'.');
	  if(ptr==NULL) {
	    tmp=strlen(argv[i]);
	  }
	  else {
	    tmp=ptr-argv[i];
	  }
	  strncpy(tdncname,argv[i],tmp);
	  tdncname[tmp+0]='.';
	  tdncname[tmp+1]='d';
	  tdncname[tmp+2]='n';
	  tdncname[tmp+3]='c';
	  tdncname[tmp+4]=0;

	  tdncf=fopen(tdncname,"r");
	  if(tdncf==NULL) {
	    //printf("cant open %s\n",tdncname);
	  }
	  else {
	    //printf("Reading dnc-file:%s\n",tdncname);
	    DNC_SetFile(tdncf);
	    DNC_Read();
	    fclose(tdncf);
	  }
	}

	}

	DNC_SetFile(dncf);
//	if(endnc==1) {
	  for(i=pc_start;i<=pc_end;i++) {
		if(namemapping[TagBuffer[i]]!=0&&TagBuffer[i]!=0) {
//			//fprintf(stderr,"dnc"
			fprintf(stderr,"Object: %-16s $%04X - $%04X\n",argv[namemapping[TagBuffer[i]]],startaddr[TagBuffer[i]],endaddr[TagBuffer[i]]);
			namemapping[TagBuffer[i]]=0;
		}
//	  }
	}
	
		
	fprintf(stderr,"Output File\nObject: %-16s $%04X - $%04X\n",outname,pc_start,pc_end-1);
        if(error>0) {fprintf(stderr,"\nSorry, %i errors occured!\n",error);exit(1);}	

	if(strcmp(outname,"stdout")==0) {
	  outf=stdout;
	}
	else {
	  outf=fopen(outname,"wb");
	  if(outf==NULL) {
		fprintf(stderr,"Error: Can't open output file:%s\n",outname);
		exitmem();
		//if(endnc==1)
		DNC_Exit();
		exit(1);
	  }
	}
	writemem(outf);
	fclose(outf);

	exitmem();

	if(endnc==1) {
	  dncf=fopen(dncname,"w+");
	  if(dncf==NULL) {
	    fprintf(stderr,"Error: Can't open dnc file:%s\n",dncname);
	    DNC_Exit();
	    exit(1);
	  }
	  DNC_SetFile(dncf);
	  tmp=DNC_Write(pc_start,pc_end);
	  if(tmp==-1) {
	    fprintf(stderr,"Error: Can't write dnc file:%s\n",dncname);
	    DNC_Exit();
	    exit(1);
	  }
	  fclose(dncf);
	  DNC_Exit();
	}
	return 0;
}





