/* dnc2huffman

  An Commodore-Object and a dnc files gets feed in.
  The Object will be changed, so that it is shorter
  when packed via huffman-methods

  dnc2huffman objectfile dncfile
    
  by A.Kaesmacher
  written on 12.09.2002

  TODO:
  Also care for only partially dnc-bytes

  more elegant stdin/out recognition
      
  V1.0 AK 15.09.2002
    If only one arg, inf=stdin, outf=stdout
      
  Needs dnc.o and 8bitmem.o
  		
  BUGS

*/	

//#define DEBUG

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../8bitmem.h"
#include "../dnc.h"

/*prototypes*/

/*global vars*/

int main(int argc, char ** argv)
{
	FILE * dncf;
	FILE * objf;
	char * dncname;
	char * objname;
		
	int tmp;
	int i;
	int lastarg;
	word pc,from,to;

	word anzdnc;
	word length;
	byte dh;
	float perc;

	int dist[255];

	if(argc<2) {
	  fprintf(stderr,"dnc2huffman [objfile] dncfile\n");
	  exit(1);
	}
	lastarg=argc-1;	
	dncname=argv[lastarg];
	
	if(argc==2) objname="std"; 
	else objname=argv[1];

#ifdef DEBUG
	fprintf(stderr,"OBJFILE=%s DNCFILE=%s\n",objname,dncname);
#endif
		
/* read dnc,mem */
	
	DNC_Init(0);
	
	dncf=fopen(dncname,"r");
	if(dncf==NULL) {
	  fprintf(stderr,"Can't open dnc file %s\n",dncname);
	  DNC_Exit();
	  exit(1);
	}
	DNC_SetFile(dncf);
	tmp=DNC_Read();
	if(tmp==-1) {
	  fprintf(stderr,"Can't read dnc file %s\n",dncname);
	  DNC_Exit();
	  exit(1);
	}
	fclose(dncf);
	
	initmem();
#ifdef DEBUG
	printf("8bitmem initialized\n");
	printf("file from %i to %i\n",pc_start,pc_end);
#endif	
	if(strcmp(objname,"std")==0) {
	  objf=stdin;
	}
	else {
	  objf=fopen(objname,"rb");
	}
	if(objf==NULL) {
	  fprintf(stderr,"Can't open obj file %s\n",objname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}
	tmp=readmem(objf);
	if(tmp==-1) {
	  fprintf(stderr,"Can't read obj file %s\n",objname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}
	if(strcmp(objname,"std")!=0) fclose(objf);

#ifdef DEBUG
	fprintf(stderr,"8bitmem read.\n");
	fprintf(stderr,"file begins @ %04X\n",pc_start);
#endif
	
/* Do the actual Work */

/* Assure zeros in dist */
	for(i=0;i<255;i++) dist[i]=0;

		
/* Make histogram */
	anzdnc=0;
	for(pc=pc_start;pc<pc_end;pc++) {
	  if(DNCBuffer[pc]==0) dist[mem[pc]]++;
	  else anzdnc++;
	}
/* put byte with most occurences in dh */
	tmp=0;
	for(i=0;i<255;i++) {
	  if(dist[i]>tmp) {tmp=dist[i];dh=i;}
	}

/* Some interesting Informations */
	length=pc_end-pc_start;
	perc=(float)anzdnc/(float)length*100.0;
	fprintf(stderr,"Filesize: %i DNC-Bytes: %i (%2.1f %%)\n",length,anzdnc,perc);
	fprintf(stderr,"Most popular Byte: $%02X (%i Occurances)\n",dh,dist[dh]);

/* Change all dnc to dh */
	for(pc=pc_start;pc<pc_end;pc++) {
	  if(DNCBuffer[pc]==255) {DNCBuffer[pc]=0; mem[pc]=dh;}
	}

	goto ende;

/* Write dnc, mem */

	if(strcmp(objname,"std")==0) {
	  objf=stdout;
	}
	else {
	  objf=fopen(objname,"wb");
	}
	if(objf==NULL) {
	  fprintf(stderr,"Can't open for write to obj file %s\n",objname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}

	tmp=writemem(objf);
	if(tmp==-1) {
	  fprintf(stderr,"Can't write to obj file %s\n",objname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}
	if(strcmp(objname,"std")!=0) fclose(objf);
	
	dncf=fopen(dncname,"w");
	if(dncf==NULL) {
	  fprintf(stderr,"Can't open for write to dnc file %s\n",dncname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}
	DNC_SetFile(dncf);
	tmp=DNC_Write(pc_start,pc_end);
	if(tmp==-1) {
	  fprintf(stderr,"Can't write to dnc file %s\n",dncname);
	  DNC_Exit();
	  exitmem();
	  exit(1);
	}
	//fclose(dncf);
ende:
	DNC_Exit();	
	exitmem();
	
	return 0;
}





