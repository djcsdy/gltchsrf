/*
 c64la
 Filter for manipulating Loadaddress of cbm-like object files
 (w) 2002-2003 by A.Kaesmacher

 V 1.6 Rational argument parsing
 V 1.5 More Bugs removed, Version string
 V 1.4 Output like file-utility
 V 1.3 DJGPP-Passed (still needs work for turboc)
 V 1.2 Implement -l 0 to remove loadaddress (+l 0 would do nothing)
 V 1.1 Several Bugs removed
 V 1.0 Better return values

c64la files..
 Displays loadaddress of files

 c64la -l $3000 file
 Changes loadaddress of file to $3000

c64la +l $3000 file
 Adds a loadaddress to a binary file (e.g. ROMZ,some xasms)

c64la -l 0 file
 Remove loadaddress from file

*/

char *vers="\0$VER: c64la 1.6 11-Dec-03\n";
                                                                               
#include <stdio.h>
#include <string.h>

#include "../8bitmem.h"

#define DISP 0
#define CHANGE 1
#define ADD 2
#define READY 3

/* prototypes */
int readbuffer(FILE * infile);
int writebuffer(FILE * outfile,int anz);
int copy(FILE *infile,FILE *outfile);
void usage();

/* global vars */
/* byte buffer[65535]; */
/* this is MUCH global data */
byte *buffer;


int displayla(FILE * infile){
	int tmp;
	fprintf(stderr,"Commodore Object, ");
	tmp=readla(infile);
	if(tmp==-1) {
	  fprintf(stderr,"Can't read Loadaddress\n");
	  return -1;
	}
	fprintf(stderr,"LOADADDRESS=$%04X\n",tmp);
	return 0;
}

int readbuffer(FILE * infile) {
	int tmp;
	byte data;
	int i=0;
	while(1) {
	  tmp=fgetc(infile);
	  data=(byte) tmp;
	  if(tmp==EOF) break;
	  buffer[i]=data;
	  i++;
	}
	return i;
}

int writebuffer(FILE * outfile,int anz) {
	int i=0;
	for(i=0;i<anz;i++) {
	  fputc(buffer[i],outfile);
	}
	return 0;
}

int copy(FILE *infile,FILE *outfile){
	int tmp;
	byte data;
	tmp=fgetc(infile);
	data=(byte) tmp;
	while(tmp!=EOF){
	  if(fputc(data,outfile)==EOF) return EOF;
	  tmp=fgetc(infile);
	  data=(byte) tmp;
	}
	return 0;
}

void finish(int n)
{
  free(mem);
  exit(n);
}

void usage() {
	fprintf(stderr,"c64la [+-l addr] [file]\n");
}
void version() {
	fprintf(stderr,vers+7);
}

int main(int argc, char *argv[] )
{
	int tmp,i;
	int ppc,pm;
	
	word pc,addr;
	FILE * inf;
	FILE * outf;

	buffer=malloc(65535);
	if(buffer==NULL) {
	  printf("Can't alloc Memory\n");
	  exit(20);
	}
	
	ppc=0;pm=DISP;
		
	for(i=1;i<argc;i++)
	{
	  if(ppc) //we are awaiting an address
	  {
	    tmp=hex2i(argv[2]);
	    if(tmp==-1) 
	    {
		  fprintf(stderr,"Error-Number not recognized\n");
		  finish(1);
	    }
	    addr=(word)tmp;
	    ppc=0;
	  }
	  else
	  {
	    switch(pm)
	    {
	      case CHANGE:
	      {
		inf=fopen(argv[i],"rb");
		if(inf==NULL) 
		{
		  fprintf(stderr,"Can't open input file %s\n",argv[3]);
		  finish(1);
		} 
		tmp=readla(inf);
		if(addr==0) fprintf(stderr,"removing loadaddress $%04X\n",tmp);
		else fprintf(stderr,"changing loadaddress $%04X to $%04X\n",tmp,addr);
		tmp=readbuffer(inf);
		fclose(inf);
		
		outf=fopen(argv[i],"wb");  
		writela(addr,outf);
		writebuffer(outf,tmp);
		fclose(outf);	  	
		pm=READY;
	  	break;
	      }	
	      case ADD:
	      {
		inf=fopen(argv[i],"rb");
		if(inf==NULL) 
		{
		  fprintf(stderr,"Can't open input file %s\n",argv[3]);
		  finish(1);
		} 
		if(addr!=0) fprintf(stderr,"adding loadaddress $%04X\n",addr);
		tmp=readbuffer(inf);
		fclose(inf);
		
		outf=fopen(argv[i],"wb");  
		writela(addr,outf);
		writebuffer(outf,tmp);
		fclose(outf);	  	
		pm=READY;
	  	break;
	      }
	      default: 
  	      {
  	        if(!strcmp(argv[i],"-l")) {pm=CHANGE;ppc=1;break;}
  	        if(!strcmp(argv[i],"+l")) {pm=ADD;ppc=1;break;}
                if(!strcmp(argv[i],"-h")) {usage();pm=READY;break;}
                if(!strcmp(argv[i],"-v")) {version();pm=READY;break;}
		inf=fopen(argv[i],"rb");
		if(inf==NULL) {
		  fprintf(stderr,"Can't open input file %s\n",argv[i]);
		  finish(1);
		} 
		fprintf(stderr,"%s:\t",argv[i]);
		tmp=displayla(inf);
		if(tmp==-1) {
		  fprintf(stderr,"Can't read Loaddress from %s\n",argv[i]);
		  finish(1);
		}
		fclose(inf);
		pm=READY;
		break;
  	      }   
	    } //switch
	  } //else
	} //for

	if(ppc) {fprintf(stderr,"missing address\n");free(mem);exit(1);}
	
	switch(pm)
	{
	  case DISP: //display stdin
	  {
	    tmp=displayla(stdin);
	    if(tmp==-1) {
	      fprintf(stderr,"Can't read Loadaddress from stdin\n");
	      finish(1);
	    }
	    break;
	  }
	  case ADD: //add to stdin
	  {
	    writela(addr,stdout);
	    copy(stdin,stdout);
	    break;
	  }
	  case CHANGE: //change stdin
	  {
	    tmp=readla(stdin);
            if(addr==0) fprintf(stderr,"removing loadaddress $%04X\n",tmp);
	    else fprintf(stderr,"changing loadaddress $%04X to $%04X\n",tmp,addr);
	    writela(addr,stdout);
	    copy(stdin,stdout);
	    break;
	  }
	}

	finish(0);
}

