/*------------------------------------
k2profiler

 by a.kaesmacher
  V1.2: curses removed
------------------------------------*/

#include <stdio.h>
#include <popt.h>
#ifndef POPT_TABLEEND
#define POPT_TABLEEND  { NULL, 0, 0, NULL, 0 }
#endif

//#include <curses.h>

#include "M6502.h"

#define DEBUG

char *vers="\0$VER: k2profiler 1.3 23-Aug-04\n";

// Function Declaration
int readla(FILE * handle);
void print_registers(M6502 *cpu,int cycle);
int loadobj(char * filename);
void loadhdr(char * filename);
void setParams(int argc, char** argv);
void printscope(int owner);
void printstat(int read, int write, int opcodes, int cycles);
//void k2war();
//void wplot(WINDOW * win,int p,char c);

// Global Variables
char * objname;
int v;
int execadr;
//int corewar;
byte iaccu,inix,iniy,inis;
unsigned int maxcycles;
unsigned int update;

unsigned char *mem;
M6502 *cpu; 
M6502 *prevcpu;

int totalcycles;
unsigned int *cycletab;
unsigned int *readtab;
unsigned int *writetab;
unsigned int *opcodetab;

char ownername[256][40];
int ownerstart[256];
int ownerend[256];
int anzowner;

int lastread;
int lastwrite;

int stopit;
unsigned int totalreads,totalwrites;
 
int main(int argc, char **argv) {
    word pc;
    int i,j;
    int lastcycles;
    int totalopcodes;
    int xterupdate;
    int scoperead,scopewrite,scopeopcode,scopecycle;
    int uread,uwrite,uopcode,ucycle;
    int zread,zwrite,zopcode,zcycle;
                    
    mem=(unsigned char *)malloc(65536);
    cpu=(M6502 *)malloc(sizeof(M6502));
    prevcpu=(M6502 *)malloc(sizeof(M6502));
    cycletab=(unsigned int *)malloc(65536*(sizeof(unsigned int)));
    readtab=(unsigned int *)malloc(65536*(sizeof(unsigned int)));
    writetab=(unsigned int *)malloc(65536*(sizeof(unsigned int)));
    opcodetab=(unsigned int *)malloc(65536*(sizeof(unsigned int)));    
    if(mem==NULL || cpu==NULL || cycletab==NULL || opcodetab==NULL || readtab==NULL || writetab==NULL) {
    	fprintf(stderr,"Hostsystem Error: Can't allocate Memory\n");
    	exit(1);
    };
    
    
    for(i=0;i<256;i++)
    {
     ownername[i][0]=0;
     ownerstart[i]=-1;
     ownerend[i]=-1;
    }
    anzowner=0;
        
    pc=0;
    stopit=0;
    xterupdate=1;	
    setParams(argc,argv);


    Wr6502(0xfff0,0x20);
    Wr6502(0xfff1,execadr%256);
    Wr6502(0xfff2,execadr/256);
    Wr6502(0xfff3,0x00);
    
    //Wr6502(0xFFFC,0xF0);
    //Wr6502(0xFFFD,0xFF);
    
    //Reset6502(cpu);
    cpu->A=iaccu;
    cpu->X=inix;
    cpu->Y=iniy;
    cpu->P=inis;//Z_FLAG|R_FLAG;
    cpu->S=0xFF;
    cpu->PC.W=0xFFF0;
    //R->PC.B.l=Rd6502(0xFFFC);
    //R->PC.B.h=Rd6502(0xFFFD);
    cpu->ICount=cpu->IPeriod;
    cpu->IRequest=INT_NONE;
    cpu->AfterCLI=0;
    cpu->TrapBadOps=1;
    pc=Exec6502(cpu);

    for(i=0;i<65536;i++) 
    {
      cycletab[i]=0;
      readtab[i]=0;
      writetab[i]=0;
      opcodetab[i]=0;
    }
    totalopcodes=0;
    totalreads=0;
    totalwrites=0;
    totalcycles=0;
    lastread=-1;
    lastwrite=-1;
    
//    if(corewar==1) k2war();

    if(v>1)
    {
      printf("\n PC  AC XR YR SP NV-BDIZC CYCLES\n");
      print_registers(cpu,totalcycles);
    }

    if(v>0)printf("\n PC  AC XR YR SP NV-BDIZC CYCLES\n");
        
    while(!stopit) {
      cpu->ICount=10;
      memcpy(prevcpu,cpu,sizeof(M6502));
      pc=Exec6502(cpu);
      if(pc==0xFFF3) break; //RTS to caller
      totalopcodes++;
      opcodetab[prevcpu->PC.W]++; //opcodetab[pc]++;
      lastcycles=10-cpu->ICount;
      totalcycles+=lastcycles;
      cycletab[pc]+=lastcycles;
      if(totalcycles>xterupdate*update)
      {
        if(v>0)print_registers(cpu,totalcycles);
        xterupdate++;
      }
    }
    //if(stopit&&!corewar) printf("\n BRK occured\n");    
    if(stopit) printf("\n BRK occured\n");
    if(v==0) printf("%i\n",totalcycles);
    if(v>0)
    {
      print_registers(prevcpu,totalcycles);
      printf("\n");
    }
    if(v>2)
    {
      printf("--------------------------------\n\n");

      printf("Scope               ");
      printf("  Reads  ");
      printf(" Writes  ");
      printf("Opcodes  ");
      printf(" Cycles  ");
      printf("\n");
    }
    
    /* Do we use the Zeropage enough ? */
    if(v>4)
    {
      zread=0;
      zwrite=0;
      zopcode=0;
      zcycle=0;
      printf("Zeropage           ");
      for(i=0;i<256;i++)
      {
       zread+=readtab[i];
       zwrite+=writetab[i];
       zopcode+=opcodetab[i];
       zcycle+=cycletab[i];
      }
      printstat(zread,zwrite,zopcode,zcycle);
    }           
    /* Lets analyse .hdr files and print which routine
       wasted how many cycles */
    if(v>4)
    {
      for(i=1;i<=anzowner;i++)
      {
        printf("%-18s ",ownername[i]);
        scoperead=0;
        scopewrite=0;
        scopeopcode=0;
        scopecycle=0;
        for(j=ownerstart[i];j<=ownerend[i];j++)
        {
          scoperead+=readtab[j];
          scopewrite+=writetab[j];
          scopeopcode+=opcodetab[j];
          scopecycle+=cycletab[j];
        }
        printstat(scoperead,scopewrite,scopeopcode,scopecycle);
      }
    }
    
    /* Lets look for the unscoped accesses */
    if(v>3)
    {
      printf("Uncategorized      ");
      
      uread=0;
      uwrite=0;
      uopcode=0;
      ucycle=0;
      
      for(i=1;i<=anzowner;i++)
      {
        for(j=ownerstart[i];j<=ownerend[i];j++)
        {
          readtab[j]=0;
          writetab[j]=0;
          opcodetab[j]=0;
          cycletab[j]=0;
        }
      }
      for(i=0;i<65536;i++)
      {
        uread+=readtab[i];
        uwrite+=writetab[i];
        uopcode+=opcodetab[i];
        ucycle+=cycletab[i];
      }
      printstat(uread,uwrite,uopcode,ucycle);
    }
    if(v>3)
    {    
      printf("------------------ -------- -------- -------- --------\n");
    }
    if(v>2)
    {
      printf("Total:             ");
      printstat(totalreads,totalwrites,totalopcodes,totalcycles);
    }

    
    if(v>6)
    {
      if(uopcode!=0)
      {
        printf("Uncategorized Opcodes: ");
        for(i=0;i<65536;i++)
        {
         if(opcodetab[i]!=0) printf("$%04X ",i);
        }
        printf("\n");
      }
      if(uread!=0)
      {
        printf("Uncategorized Readaccesses: ");
        for(i=0;i<65536;i++)
        {
         if(readtab[i]!=0) printf("$%04X ",i);
        }
        printf("\n");
      }
      if(uwrite!=0)
      {
        printf("Uncategorized Writeaccesses: ");
        for(i=0;i<65536;i++)
        {
          if(writetab[i]!=0) printf("$%04X ",i);
        }
        printf("\n");
      }
      
    }

    //Hiernach kommt ein Bus Error auf PS2!
/*
    free(readtab);
    
    free(writetab);

    printf("Here comes the error\n");
    free(cycletab);       
    printf("This will not occur\n");

    free(mem);
    free(cpu);
*/
    exit(0);
}
void printstat(int read, int write, int opcodes, int cycles)
{
  printf("%8i %8i %8i ",read,write,opcodes,cycles);
  printf("%8i ",cycles);
  if(cycles>985248) {printf("(%.3f seconds)\n",(float)cycles/(float)985248);return;}
  if(cycles>(63*312)) {printf("(%.2f frames)\n",(float)cycles/(float)(63*312));return;}
  if(cycles>63) {printf("(%.1f lines)\n",(float)cycles/(float)63);return;}
  printf("\n");
}

void printscope(int owner)
{
  if(owner==0||owner>anzowner)
  {
    printf("NOT A VALID SCOPE!\n");return;
  }
  printf("Scope: %-20s\t$%04X - $%04X\n",ownername[owner],ownerstart[owner],ownerend[owner]);
  
}

// DOES NOT CHECK FOR DOUBLE-DEFINITIONS!
void loadhdr(char * filename)
{
    FILE * inf;
    char temp[40];
    int address;
    int i;
    
    inf=fopen(filename,"r");
    if(inf==NULL) {fprintf(stderr,"cant load %s\n",filename);}
    address=-1;
    while(fscanf(inf,"%s = $%x",temp,&address)!=EOF)
    {
      if(address!=-1)
      {
        if(strstr(temp,"._end")==NULL)
        {
          anzowner++;
          strcpy(ownername[anzowner],temp);
          ownerstart[anzowner]=address;
  	  ownerend[anzowner]=address; //In case there is no ._end
        }
        else
        {
          temp[strlen(temp)-5]=0;
  	  for(i=1;i<=anzowner;i++)
  	  {
  	    if(strcmp(ownername[i],temp)==0)
  	    {
  	      ownerend[i]=address;
  	      break;
  	    }
  	  }
        }
        address=-1;
      }
    }
    
    fclose(inf);
}

int loadobj(char * filename)
{
    FILE * inf;
    int la=0;
    int i;
    int pc;
            
    inf=fopen(filename,"rb");
    if(inf==NULL) { printf("cant load %s\n",filename);}
    la=readla(inf);
    pc=la;

    if(v>5) printf("Object: %-17s $%04X - ",filename,la);

    i=fgetc(inf);
    while(i!=EOF) {
      Wr6502(pc++,i);
      i=fgetc(inf);
    }

    if(v>5)printf("$%04X\n",pc-1);

    fclose(inf);
    return la;
}

int readla(FILE * inf)
{
    int hi,lo,pc;
    lo=fgetc(inf);
    hi=fgetc(inf);
    pc=lo+256*hi;
    return pc;
}

void print_registers(M6502 *cpu,int cycle)
{
    char status[9];
    status[0]=cpu->P&N_FLAG ? '*':'.';
    status[1]=cpu->P&V_FLAG ? '*':'.';
    status[2]='*';
    status[3]=cpu->P&B_FLAG ? '*':'.';
    status[4]=cpu->P&D_FLAG ? '*':'.';
    status[5]=cpu->P&I_FLAG ? '*':'.';
    status[6]=cpu->P&Z_FLAG ? '*':'.';
    status[7]=cpu->P&C_FLAG ? '*':'.';
    status[8]=0;      
//  printf(" PC   AC   XR   YR   SP NV-BDIZC CYCLES\n");
    printf("%04X %02X %02X %02X %02X %s %6i\r",\
    cpu->PC.W,cpu->A,cpu->X,cpu->Y,cpu->S,status,cycle);

}



byte Loop6502(register M6502 *R) {
	return INT_NONE;
}

////////////////////////////////////////////////////////////////
/* 6502 Emulation starts here */

byte Rs6502(register word adr) {
   return mem[adr];
}

void Ws6502(register word adr,register byte wert) {
   mem[adr]=wert;
}

byte Op6502(register word adr) {
   return mem[adr];
}


byte Rd6502(register word adr) {
   if(adr==0xFFFF) {stopit=1;return mem[adr];} //UGLY Hack
   lastread=adr;
   totalreads++;
   readtab[adr]++;
   return mem[adr];
}

void Wr6502(register word adr,register byte wert) {
   lastwrite=adr;
   totalwrites++;
   writetab[adr]++;
   mem[adr]=wert;
}

/******************************************/
void setParams(int argc, char** argv) {
	char c;
	char * addrstring;
	poptContext optCon;
	int i;
	char * postfix1,postfix2;
	char inixstr[10];

	
	// TODO: Allow hexadecimal values for parameters
	
	struct poptOption optionsTable[] = {
	  { "execadress", 'e', POPT_ARG_INT, &execadr,0,"Execadress (default=loadadress of first object)"},
	  { "accu", 'a', POPT_ARG_INT, &iaccu,0,"Initial Accu (default=0)"},
	  { "xregister", 'x', POPT_ARG_STRING, &inixstr,0,"Initial X-Register (default=0)"},
	  { "yregister", 'y', POPT_ARG_INT, &iniy,0,"Initial Y-Register (default=0)"},
	  { "statusregister", 's', POPT_ARG_INT, &inis,0,"Initial Status-Register (default=34)"},
	  { "maximumcycles", 'm', POPT_ARG_INT, &maxcycles,0,"Maximum Cycles (default=eternity)"},  
	  { "update", 'u', POPT_ARG_INT, &update,0,"Displayupdate (default=1000)"},
	  { "verbosity", 'v', POPT_ARG_INT,&v,0, "Verbosity 0=shut the f*ck up, 7=sermon (default=5)" },
	  //{ "corewar", 'c', 0,0,'c', "Corewar-like Visualisation" },
	  POPT_AUTOHELP
	  POPT_TABLEEND
	};

	/* defaults */
	v=5;
	execadr=-1;
	//corewar=0;
	iaccu=0;
	inix=0;
	iniy=0;
        inis=Z_FLAG|R_FLAG;
	maxcycles=0;
	update=-1;
	// Kann mir mal irgendjemand erklaeren, warum bei x (und nur bei x) bei
	// POPT_ARG_INT immer die Fehlermeldung mutually exclusive operation requested
	// rausgehauen wird ????				
	inixstr[0]='0';inixstr[1]='\0';
	
	/* argument parsing */
	optCon=poptGetContext(NULL,argc,argv,optionsTable,0);
	poptSetOtherOptionHelp(optCon, "objfile.. [hdrfile..]");
	
	//fprintf(stderr,"Wie bitte?\n");
		
	while ((c = poptGetNextOpt(optCon)) >= 0) {
	  switch(c) {
	    //case 'c': corewar=1;v=0;break;
      //TODO: Version switch
      case 'c': v=0;break;
	  }
	}

	//fprintf(stderr,"Was hast du gegen -x?\n");
	sscanf(inixstr,"%i",&inix);
		
	if(c<-1) {
	  fprintf(stderr,"%s: %s\n",
	    poptBadOption(optCon,POPT_BADOPTION_NOALIAS),
	    poptStrerror(c));
	  exit(1);
	}
	
	if(update==-1)
	{
	 //if(corewar==1) update=100;
	 //else update=1000;
   update=1000;
	}
	
	
	objname=poptGetArg(optCon);

        if(objname==NULL) {
           fprintf(stderr,"Please specify at least one object-file\n");
           exit(1);
        };

        if(v>3)printf("\nk2profiler V1.1  [/] Zed Yago/K2\n");
        
        i=loadobj(objname);
        if(execadr==-1) execadr=i;

	while((objname=poptGetArg(optCon))!=NULL)
	{
	  postfix1=strstr(objname,".hdr");
	  postfix2=strstr(objname,".inc");
	  if(postfix1!=NULL || postfix2!=NULL)
	  {
	    loadhdr(objname);  
	  }
	  else
	  {
	    loadobj(objname);
	  }
	}

	if(v>5)
	{
       	  printf("\n");
       	  for(i=1;i<=anzowner;i++)
       	  {
       	    printscope(i);
       	  }
       	  printf("\n");
    	}			
	poptFreeContext(optCon);		

}

#if 0
/**************************************************
 Lets play 6502 Corewar!
 *************************************************/

void k2war()
{
  char tcstr[9];
  int pc;
  int totalopcodes=0;
  int lastcycles;  
  int i,j;
  int xterupdate=1;
      
  WINDOW * core;
  WINDOW * mon;
      
  initscr();
  cbreak();
  noecho();
  nonl();
  intrflush(stdscr,FALSE);
  keypad(stdscr,TRUE);
  
  start_color();
  init_pair(1,COLOR_BLACK,COLOR_WHITE);
  init_pair(2,COLOR_WHITE,COLOR_BLACK);

  attrset(COLOR_PAIR(2));
  clear();
  
  core=newwin(20,64,0,0);
  wattrset(core,COLOR_PAIR(2));
  wclear(core);

  mvwaddstr(core,0,0,"zzzzzzssssss");

  wrefresh(core);
//  while(getch()==ERR) {;}
  
  mon=newwin(20,10,0,70);
  wattrset(mon,COLOR_PAIR(2));
  wclear(mon);
      
  /* some layout */
  /* we assume a 80x24 screen */
  
  wrefresh(mon);
  refresh();
      
  while(!stopit)
  {
    cpu->ICount=10;
    pc=Exec6502(cpu);
    if(pc==0xFFF3) break; //RTS to caller
    totalopcodes++;
    opcodetab[pc]++;
    lastcycles=10-cpu->ICount;
    totalcycles+=lastcycles;

    mvwaddstr(mon,0,0,"CYCLES");

    wmove(mon,1,1);
    wprintw(mon,"%08i",totalcycles);
    wrefresh(mon);

    //memory-dots
    for(i=0;i<65536;i+=46)
    {
      wplot(core,i,'.');
    }
    //z=zeropage
    for(i=0;i<256;i+=46)
    {
      wplot(core,i,'z');
    }
    //s=stack
    for(i=256;i<512;i+=46)
    {
      wplot(core,i,'s');
    }
    //now the first chars of the scopes
    for(i=1;i<=anzowner;i++)
    {
      for(j=ownerstart[i];j<=ownerend[i];j+=46)
      {
        wplot(core,j,ownername[i][0]);
      }
    }
    wattrset(core,COLOR_PAIR(1));
    wplot(core,lastread,'R');
    wplot(core,lastwrite,'W');
    wplot(core,pc,'*');
    wattrset(core,COLOR_PAIR(2));

    if(totalcycles>xterupdate*update)
    {
      //while(getch()==ERR) {;}
      wrefresh(core);
      xterupdate++;
    }

  }  
  
  //OK, das wars dann wohl!
  stopit=1;
  delwin(core);
  endwin();
}

void wplot(WINDOW * win,int p,char c)
{
  int t,x,y;
  //we assume 64*24
  //each cell is 46 bytes width
  if(p<0) return;
  t=p/46;
  x=t%64;
  y=t/64;
  mvwaddch(win,y,x,c);
  
}
#endif
