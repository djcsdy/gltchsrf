/* ppminterlace

   Very easy: Erases every second line
	    
  -lpbm 
 
*/	

char *vers="\0$VER: ppminterlace 1.1 05-Jun-04\n";
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include <ppm.h>
#include <pgm.h>
#include <pbm.h>

#include <popt.h>
#ifndef POPT_TABLEEND
#define POPT_TABLEEND  { NULL, 0, 0, NULL, 0 }
#endif

#define EMPTY 0
#define DOUBLE 1

/*prototypes*/
void interlace(int modus);
void setParams(int argc, char** argv);

/*global vars*/

int cols,rows,maxval;
int mode;

pixel** bitmap;

int debug;

int main(int argc, char ** argv)
{
	FILE * ipmf;
	FILE * opmf;
	
	ppm_init(&argc,argv);
	
	setParams(argc,argv);
	
	ipmf=stdin;

	bitmap=ppm_readppm(ipmf,&cols,&rows,&maxval);
	
	interlace(mode);

	opmf=stdout;
	
	ppm_writeppm(opmf,bitmap,cols,rows,PPM_MAXMAXVAL,0);
		
	return 0;
}
/********************************************/
void interlace(int modus) 
{
  int x,y;
  pixel black;
  black=ppm_parsecolor("black",PPM_MAXMAXVAL);
  for(y=0;y<rows;y++)
  {
   if(y&1)
   {
    if(modus==EMPTY)
      for(x=0;x<cols;x++) bitmap[y][x]=black;
    if(modus==DOUBLE)
      for(x=0;x<cols;x++) bitmap[y][x]=bitmap[y-1][x];
   }
  }
}

/******************************************/
void setParams(int argc, char** argv) {
	char c;
	poptContext optCon;

	struct poptOption optionsTable[] = {
          { "double", 'd',0,0,'d', "Duplicate Lines"},
	  { "version", 'v', 0,0,'v', "Print Version" },
	  POPT_AUTOHELP
	  POPT_TABLEEND
	};

	/* defaults */
	debug=0;
        mode=EMPTY;
                                					
	/* argument parsing */
	optCon=poptGetContext(NULL,argc,argv,optionsTable,0);
	poptSetOtherOptionHelp(optCon, "d64file file");
	
	while ((c = poptGetNextOpt(optCon)) >= 0) {
	  switch(c) {
            case 'd': mode=DOUBLE;break;
	    case 'v': fprintf(stderr,"%s",vers+7);exit(1);break;
	  }
	}
	
	if(c<-1) {
	  fprintf(stderr,"%s: %s\n",
	    poptBadOption(optCon,POPT_BADOPTION_NOALIAS),
	    poptStrerror(c));
	  exit(1);
	}
	
	
	//d64name=poptGetArg(optCon);
	
	//prgname=poptGetArg(optCon);
	
	poptFreeContext(optCon);		

}
