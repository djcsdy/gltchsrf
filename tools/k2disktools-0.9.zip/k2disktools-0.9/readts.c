/* readts

  Writes a sector from a d64-archive to stdout
  TODO: Only write relevant sector, not whole disk!
         
*/	

char *vers="\0$VER: readts 1.0 27-Dec-03\n";
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*prototypes*/
void setParams(int argc, char** argv);
int readd64(FILE * d64f);

/*global vars*/

char * d64name;
FILE * d64f;
int track,sector;

unsigned char d64image[36][21][256];

unsigned char spt[36]={0,
/* 1-17 */             20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,
/*18-24 */             18,18,18,18,18,18,18,
/*25-30 */             17,17,17,17,17,17,
/*31-35 */             16,16,16,16,16
                      };
                           
int debug;
int interleave;

int main(int argc, char ** argv)
{
	int i,j;
	int t,s;
	
	setParams(argc,argv);

        if(track<1||track>35) {printf("Illegal Track:%i!\n",track);return 1;}
        if(sector<0||sector>spt[track]) {printf("Illegal Sector:%i!\n",sector);return 1;}
        
        if(d64name!=NULL) d64f=fopen(d64name,"rb");
        if(d64f==NULL) {printf("Cant open %s!\n",d64name);return 1;}
        
        i=readd64(d64f);
        if(i!=0) {printf("Cant read %s!\n",d64name);return 1;}

        for(i=0;i<256;i++)
          printf("%c",d64image[track][sector][i]);

	return 0;
}
/******************************************/
/******************************************/
int readd64(FILE * d64f)
{
 int t,s,b;
 int i;
 for(t=1;t<36;t++)
 {
  for(s=0;s<=spt[t];s++)
  {
    //fprintf(stderr,"Reading track %02i, sector %02i\r",t,s);
    for(b=0;b<256;b++)
    {
      i=fgetc(d64f);
      if(i==EOF) return -1;
      d64image[t][s][b]=i;
    }
  }
 }
 fprintf(stderr,"\n");
 return 0;
}

/******************************************/
void setParams(int argc, char** argv) {
	char c;
        
        track=-1;
        sector=-1;

        if(argc!=4)
        {
         fprintf(stderr,"%s",vers+7);
         fprintf(stderr,"readts d64file track sector\n");
         exit(1);
        }        
        
	d64name=argv[1];
	
        sscanf(argv[2],"%i",&track);

        sscanf(argv[3],"%i",&sector);
        	

}
