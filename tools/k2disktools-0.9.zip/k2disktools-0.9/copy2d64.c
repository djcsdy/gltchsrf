/* copy2d64

  Write files into an already existing d64-archive

  Kudos to Norman Yen for his copy2d64.pas!

  TODO: Warning when requested Track is full
    
  -lpopt
 
*/	

char *vers="\0$VER: copy2d64 1.6 02-Feb-04\n";
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <popt.h>
#ifndef POPT_TABLEEND
#define POPT_TABLEEND  { NULL, 0, 0, NULL, 0 }
#endif

#include "../8bitmem.h"

#define NORMAL 0
#define RAW 1

/*prototypes*/
void setParams(int argc, char** argv);
int readd64(FILE * d64f);
int writed64(FILE * d64f);
int isfree(int track,int sector);
int alloc(int track,int sector);
int loadchunk();
int nextfree(int miss);
int firstfree();
void writetrack(int track,int sector);

/*global vars*/

char * d64name;
FILE * d64f;

char * prgname;
FILE * prgf;

unsigned char d64image[36][21][256];
unsigned char ttrack[256];

int curt,curs,lasts;
int dirt,dirs,dirb;

int spt[36]={ 0,
/* 1-17 */   20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,
/*18-24 */   18,18,18,18,18,18,18,
/*25-30 */   17,17,17,17,17,17,
/*31-35 */   16,16,16,16,16
            };
                           
int debug;
int interleave;
int movement;
int mode;
int starttrack,startsector;
int direction;
int fake;

int main(int argc, char ** argv)
{
	int i,j;
	int t,s;
	int lt,ls;
	int la;
        int length;
        char xlat[256];
        int b;
        int umdrehen;
        
        umdrehen=0;
        
        /* simple ascii->petscii table */
        for(i=0;i<256;i++) xlat[i]=0;
        for(i=32;i<59;i++) xlat[i]=i;
        for(i=96;i<123;i++) xlat[i]=i-32;
                	
	setParams(argc,argv);

        if(d64name!=NULL) d64f=fopen(d64name,"rb");
        if(d64f==NULL) {printf("Cant open %s!\n",d64name);return 1;}
        
        i=readd64(d64f);
        if(i!=0) {printf("Cant read %s!\n",d64name);return 1;}
        fclose(d64f);
        
        if(prgname!=NULL) prgf=fopen(prgname,"rb");
        if(prgf==NULL) {printf("Cant open %s!\n",prgname);return 1;}

        curt=starttrack;curs=startsector; 

        /* the first ts can be anywhere.. */
        i=curt;
        if(firstfree())
        {
         printf("ERROR: Disk completely filled!\n");
         return 1;
        }
        if(i!=curt)
        {
         printf("Warning: Starting at Track %i instead of Track %i!\n",curt,i);
        }
        //printf("File starts at %i,%i\n",curt,curs);
        
        if(mode==RAW)
        {
         la=readla(prgf);
         printf(";%s\n",prgname);
         printf(".word %i\n",la);          
         
         i=-1;
         while(i==-1)
         {
          i=loadchunk();
          if(nextfree(0)==0)
          {
            alloc(curt,curs);
            writetrack(curt,curs);
            printf(".byte %i,%i\n",curt,curs);
          }
          else
          {
            printf("ERROR: Not enough space!\n");
            return 1;
          }
         }
         printf(".byte 0,%i\n",i);

         fclose(prgf);
         
        }

        if(mode==NORMAL)
        {
          dirt=18;dirs=1;dirb=2;
          if(!getfreedir()) {printf("Directory full!\n");return 1;}
          //now we have an allocated dir-entry at dirt,dirs,dirb
          
          for(i=0;i<0x20;i++) d64image[dirt][dirs][dirb+i]=0;
          d64image[dirt][dirs][dirb]=0x82; //PRG
          d64image[dirt][dirs][dirb+1]=curt;
          d64image[dirt][dirs][dirb+2]=curs; 
          
          //now the name
          for(i=0;i<16;i++) d64image[dirt][dirs][dirb+3+i]=0xA0;
          
          //as long as i am still sober, lets implement basename!
          for(b=strlen(prgname);b>0;b--)
          {
            if (prgname[b]=='/') {b++;break;}
          }

          for(i=0;i<16;i++)
          {
           if(prgname[i+b]==0) break;
           d64image[dirt][dirs][dirb+3+i]=xlat[prgname[i+b]];
          }

          i=-1;
          lt=0;ls=0;
          length=0;
          while(i==-1)
          {
           i=loadchunk();
           if(nextfree(0)!=0)
           {
            if(umdrehen)
            {
              printf("ERROR: Not enough space!\n");
              return 1;
            }
            printf("Warning: Changing Direction!\n");
            umdrehen=1;
            direction=-direction;
            if(curt>18) curt=17;
            else curt=19;
            curs=0;
            if(nextfree(0)!=0)
            {
             printf("ERROR: Not enough space!\n");
             return 1;
            }
           }

           alloc(curt,curs);
           writetrack(curt,curs);
           length++;
           if(lt)
           {
            d64image[lt][ls][0]=curt;
            d64image[lt][ls][1]=curs;
           }
           lt=curt;ls=curs;
          }
          
          d64image[curt][curs][0]=0;
          d64image[curt][curs][1]=i-1;          
          if(fake==-1) 
          { 
           d64image[dirt][dirs][dirb+28]=length&255;
           d64image[dirt][dirs][dirb+29]=length/256;
          }
          else 
          {
           d64image[dirt][dirs][dirb+28]=fake&255;
           d64image[dirt][dirs][dirb+29]=fake/256;
          }
        }
        
        if(d64name!=NULL) d64f=fopen(d64name,"wb");
        if(d64f==NULL) {printf("Cant open %s!\n",d64name);return 1;}
        
        i=writed64(d64f);
        if(i!=0) {printf("Cant write %s!\n",d64name);return 1;}
        fclose(d64f);
                          
	return 0;
}
/*****************************************/
/* First Free Sector in a Track          */
/*****************************************/
int firstfree()
{
 int umdrehen;
 umdrehen=0;
 
 while(!isfree(curt,curs))
 {
  curs++;
  if (curs>spt[curt]) 
  {
   curt+=direction;
   curs=0;
  }
  if(curt>35 || curt<1 )
  {
   printf("Warning: Changing Direction!\n");
   if(umdrehen) return -1;
   direction=-direction;
   umdrehen=1;
   if(curt>18) curt=17;
   else curt=19;
   curs=0;
  }
 }
 return 0;
 
}

/*****************************************/
/* Recursive search for next free sector */
/*****************************************/
int nextfree(int miss)
{
  int mymiss;
  mymiss=miss;
  
  if(curt>35||curt<1) return -1;

  if(isfree(curt,curs)) {lasts=curs;return 0;}

  curs=curs+interleave;
  if(curs>spt[curt]) { curs=curs-(spt[curt]+1);}

  if(isfree(curt,curs)) {lasts=curs;return 0;}
  if(mymiss==0)
  { 
   mymiss++;
   curs=curs+1;
   if(curs>spt[curt]) {curs=curs-(spt[curt]+1);}
   return nextfree(mymiss);
  }
  curt+=direction;mymiss=0;
  curs=lasts+movement;
  if(curs>spt[curt]) { curs=curs-(spt[curt]+1);}
  return nextfree(mymiss);
}

/******************************************/
int getfreedir()
{
  int i;
  int lt,ls;
  if(dirt!=18) return 0; //FAILURE
  if(isfree(dirt,dirs))
  {
   alloc(dirt,dirs);
   dirb=2;
   for(i=0;i<256;i++) d64image[dirt][dirs][i]=0;
   d64image[dirt][dirs][1]=0xFF;
   return 1; //SUCCESS
  }
  if(d64image[dirt][dirs][dirb]==0) return 1; //SUCCESS
  dirb+=0x20;
  if(dirb<0xff)
  {
   return getfreedir();
  }
  else
  {
   dirb=2;
   if(d64image[dirt][dirs][0]!=0) 
   { //travel along the dir
    dirt=d64image[dirt][dirs][0];
    dirs=d64image[dirt][dirs][1];
    return getfreedir();
   }
   else
   { //make new dir-block
    lt=dirt;ls=dirs;
    
    while(!isfree(dirt,dirs))
    {
     dirs++;
     alloc(dirt,dirs);
     d64image[lt][ls][0]=dirt;
     d64image[lt][ls][1]=dirs; 
     return getfreedir();
    }
   
   }
  }
  
}

/******************************************/
void writetrack(int track,int sector)
{
  int t;
  for(t=0;t<256;t++)
  {
    d64image[track][sector][t]=ttrack[t];
  }
  return;
}

/******************************************/
int loadchunk()
{
  int t,min,i;
  if(mode==RAW){min=0;}
  else min=2;
  for(t=min;t<256;t++)
  {
    i=fgetc(prgf);
    if(i==EOF) return t;
    ttrack[t]=i;
//    printf("%02i ",t);
  } 
//  printf("\n");
  return -1; //SUCCESS
}

/******************************************/
int alloc(int t,int s)
{
 //we doublecheck if the sector is really free
 if(!isfree(t,s)) return -1;
 if(d64image[18][0][t*4]==0) return -1;
 d64image[18][0][t*4+1+s/8]=d64image[18][0][t*4+1+s/8] & 255-(1<<(s&7));
 d64image[18][0][t*4]--;
 return 0;
}

/******************************************/
int isfree(int t,int s)
{
  int r;
  
  r=d64image[18][0][t*4+1+s/8] & 1<<(s&7);
  if(debug)
  {  
   printf("Track %i Sector %i is ",t,s);
   if(r) printf("free\n");
   else printf("allocated\n");
  }
  return r;
}

/******************************************/
int readd64(FILE * d64f)
{
 int t,s,b;
 int i;
 for(t=1;t<36;t++)
 {
  for(s=0;s<=spt[t];s++)
  {
    //fprintf(stderr,"Reading track %02i, sector %02i\r",t,s);
    for(b=0;b<256;b++)
    {
      i=fgetc(d64f);
      if(i==EOF) return -1;
      d64image[t][s][b]=i;
    }
  }
 }
 //fprintf(stderr,"\n");
 return 0;
}

/******************************************/
int writed64(FILE * d64f)
{
 int t,s,b;
 int i;
 for(t=1;t<36;t++)
 {
  for(s=0;s<=spt[t];s++)
  {
    //fprintf(stderr,"Reading track %02i, sector %02i\r",t,s);
    for(b=0;b<256;b++)
    {
      i=fputc(d64image[t][s][b],d64f);
      if(i==EOF) return -1;
    }
  }
 }
 //fprintf(stderr,"\n");
 return 0;
}

/******************************************/
void setParams(int argc, char** argv) {
	char c;
	poptContext optCon;

	struct poptOption optionsTable[] = {
	  { "interleave",'i',POPT_ARG_INT,&interleave,0,"interleave (default=10)"},
          { "starttrack",'t',POPT_ARG_INT,&starttrack,0,"starttrack (default=19)"},
          { "startsector",'s',POPT_ARG_INT,&startsector,0,"startsector (default=0)"},
          { "movement", 'm', POPT_ARG_INT,&movement,0,"how long it takes to move the head (default=12)"},
          { "fakelength", 'f', POPT_ARG_INT,&fake,0,"fake block length"},
          { "raw", 'r',0,0,'r', "Raw mode (without directory,linking nor startaddress)"},
          { "down", 'd',0,0,'d', "Search downward"},
	  { "version", 'v', 0,0,'v', "Print Version" },
	  POPT_AUTOHELP
	  POPT_TABLEEND
	};

	/* defaults */
	debug=0;
	interleave=10;
        movement=12;
        mode=NORMAL;
        starttrack=19;
        startsector=0;
        direction=1;
        fake=-1;
        
                                					
	/* argument parsing */
	optCon=poptGetContext(NULL,argc,argv,optionsTable,0);
	poptSetOtherOptionHelp(optCon, "d64file file");
	
	
	while ((c = poptGetNextOpt(optCon)) >= 0) {
	  switch(c) {
            case 'd': direction=-1;break;
            case 'r': mode=RAW;break;
	    case 'v': fprintf(stderr,"%s",vers+7);exit(1);break;
	  }
	}
	
	if(c<-1) {
	  fprintf(stderr,"%s: %s\n",
	    poptBadOption(optCon,POPT_BADOPTION_NOALIAS),
	    poptStrerror(c));
	  exit(1);
	}
	
	
	d64name=poptGetArg(optCon);
	
	prgname=poptGetArg(optCon);
	
	poptFreeContext(optCon);		

}
