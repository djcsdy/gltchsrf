/* copy2d64

  Write files into an already existing d64-archive

  -lpopt
 
*/	

char *vers="\0$VER: copy2d64 0.9 27-Dec-03\n";
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <popt.h>
#ifndef POPT_TABLEEND
#define POPT_TABLEEND  { NULL, 0, 0, NULL, 0 }
#endif


/*prototypes*/
void setParams(int argc, char** argv);
int readd64(FILE * d64f);
int isfree(int track,int sector);
int alloc(int track,int sector);
void writetrack(int track,int sector);
int writed64(FILE * d64f);

/*global vars*/

char * d64name;
FILE * d64f;
int allocate;
int track,sector;

unsigned char d64image[36][21][256];
unsigned char ttrack[256];

int spt[36]={ 0,
/* 1-17 */   20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,
/*18-24 */   18,18,18,18,18,18,18,
/*25-30 */   17,17,17,17,17,17,
/*31-35 */   16,16,16,16,16
            };
                           
int debug;
int mode;

int main(int argc, char ** argv)
{
	int i,j;
	int t,s;
	int la;
	
	setParams(argc,argv);
        
        if(track<1||track>35) {printf("Illegal Track!\n");return 1;}
        if(sector<0||sector>spt[track]) {printf("Illegal Sector!\n");return 1;}
        
        if(d64name!=NULL) d64f=fopen(d64name,"rb");
        if(d64f==NULL) {printf("Cant open %s!\n",d64name);return 1;}
        
        i=readd64(d64f);
        if(i!=0) {printf("Cant read %s!\n",d64name);return 1;}
        fclose(d64f);
        
        loadchunk();
        t=-1;
        if(allocate) t=alloc(track,sector);
        if(t==-1) writetrack(track,sector);
        else {printf("Already allocated!\n");return 1;}
        
        if(d64name!=NULL) d64f=fopen(d64name,"wb");
        if(d64f==NULL) {printf("Cant open %s!\n",d64name);return 1;}
        
        i=writed64(d64f);
        if(i!=0) {printf("Cant write %s!\n",d64name);return 1;}
        fclose(d64f);
                          
	return 0;
}

/******************************************/
void writetrack(int track,int sector)
{
  int t;
  for(t=0;t<256;t++)
  {
    d64image[track][sector][t]=ttrack[t];
  }
  return;
}

/******************************************/
int loadchunk()
{
  int t,i;
  for(t=0;t<256;t++)
  {
    i=fgetc(stdin);
    if(i==EOF) return t;
    ttrack[t]=i;
  } 
  return -1; //SUCCESS
}

/******************************************/
int alloc(int t,int s)
{
 //we doublecheck if the sector is really free
 if(!isfree(t,s)) return -1;
 if(d64image[18][0][t*4]==0) return -1;
 d64image[18][0][t*4+1+s/8]=d64image[18][0][t*4+1+s/8] & 255-(1<<(s&7));
 d64image[18][0][t*4]--;
 return 0;
}

/******************************************/
int isfree(int t,int s)
{
  int r;
  
  r=d64image[18][0][t*4+1+s/8] & 1<<(s&7);
  if(debug)
  {  
   printf("Track %i Sector %i is ",t,s);
   if(r) printf("free\n");
   else printf("allocated\n");
  }
  return r;
}

/******************************************/
int readd64(FILE * d64f)
{
 int t,s,b;
 int i;
 for(t=1;t<36;t++)
 {
  for(s=0;s<=spt[t];s++)
  {
    //fprintf(stderr,"Reading track %02i, sector %02i\r",t,s);
    for(b=0;b<256;b++)
    {
      i=fgetc(d64f);
      if(i==EOF) return -1;
      d64image[t][s][b]=i;
    }
  }
 }
 //fprintf(stderr,"\n");
 return 0;
}

/******************************************/
int writed64(FILE * d64f)
{
 int t,s,b;
 int i;
 for(t=1;t<36;t++)
 {
  for(s=0;s<=spt[t];s++)
  {
    //fprintf(stderr,"Reading track %02i, sector %02i\r",t,s);
    for(b=0;b<256;b++)
    {
      i=fputc(d64image[t][s][b],d64f);
      if(i==EOF) return -1;
    }
  }
 }
 //fprintf(stderr,"\n");
 return 0;
}

/******************************************/
void setParams(int argc, char** argv) {
	char c;
	poptContext optCon;

	struct poptOption optionsTable[] = {
          { "allocate", 'a',0,0,'a', "Allocate track/sector"},
	  { "version", 'v', 0,0,'v', "Print Version" },
	  POPT_AUTOHELP
	  POPT_TABLEEND
	};

	/* defaults */
	debug=0;
        allocate=0;
        track=-1;
        sector=-1;
                        					
	/* argument parsing */
	optCon=poptGetContext(NULL,argc,argv,optionsTable,0);
	poptSetOtherOptionHelp(optCon, "d64file file");
	
	
	while ((c = poptGetNextOpt(optCon)) >= 0) {
	  switch(c) {
            case 'a': allocate=1;break;
	    case 'v': fprintf(stderr,"%s",vers+7);exit(1);break;
	  }
	}
	
	if(c<-1) {
	  fprintf(stderr,"%s: %s\n",
	    poptBadOption(optCon,POPT_BADOPTION_NOALIAS),
	    poptStrerror(c));
	  exit(1);
	}
	
	
	d64name=poptGetArg(optCon);
	
        sscanf(poptGetArg(optCon),"%i",&track);
	
	sscanf(poptGetArg(optCon),"%i",&sector);		

        poptFreeContext(optCon);
}
