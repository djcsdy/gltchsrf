/* mkd64

  Creates an empty d64-archive
  
*/	

char *vers="\0$VER: mkd64 1.0 20-May-04\n";
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/*prototypes*/
void setParams(int argc, char** argv);
int writed64(FILE * d64f);
int isfree(int track,int sector);
int alloc(int track,int sector);
void freets(int track,int sector);
void writetrack(int track,int sector);

/*global vars*/

char * d64name;
FILE * d64f;
char * title;

unsigned char d64image[36][21][256];
char empty[1];

int spt[36]={ 0,
/* 1-17 */   20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,
/*18-24 */   18,18,18,18,18,18,18,
/*25-30 */   17,17,17,17,17,17,
/*31-35 */   16,16,16,16,16
            };
                           
int debug;

int main(int argc, char ** argv)
{
	int i,j;
	int t,s,b;
        char xlat[256];
        char defaultid[6];
        defaultid[0]='K';
        defaultid[1]='2';
        defaultid[2]=0xA0;
        defaultid[3]='2';
        defaultid[4]='A';
        defaultid[5]=0;
        empty[0]=0;
        
        /* simple ascii->petscii table */
        for(i=0;i<256;i++) xlat[i]=0;
        for(i=32;i<59;i++) xlat[i]=i;
        for(i=65;i<92;i++) xlat[i]=i+128;
        for(i=96;i<123;i++) xlat[i]=i-32;
                        	
	setParams(argc,argv);

        //format all tracks with 0
        for(t=1;t<36;t++)
        {
         for(s=0;s<=spt[t];s++)
         {
          //printf("Formatting Track %02i Sector %02i\r",t,s);
          for(b=0;b<256;b++)
          {
           d64image[t][s][b]=0;
          }
         }
        }
        d64image[18][0][0]=18;
        d64image[18][0][1]=1;
        d64image[18][0][2]='A';
        
        for(t=1;t<36;t++)
        {
         d64image[18][0][t*4]=spt[t]+1;
        }        
        
        for(t=1;t<36;t++)
        {
         for(s=0;s<=spt[t];s++)
         {
          freets(t,s);
         }
        }
        alloc(18,0);

        for(i=0x90;i<0xAB;i++) d64image[18][0][i]=0xA0;

        for(j=0;j<5;j++)
        {
          d64image[18][0][0xA2+j]=defaultid[j];
        }        

        for(i=0;i<16;i++)
        {
          if(title[i]==0 || title[i]==',') break;
          d64image[18][0][0x90+i]=xlat[title[i]]; 
        }
        if(i<16 && title[i]!=0)
        {
         i++;
         for(j=0;j<5;j++)
         {
          if(title[i+j]==0) break;
          d64image[18][0][0xA2+j]=xlat[title[i+j]];
         }        
        }
        
        if(d64name!=NULL) d64f=fopen(d64name,"wb");
        if(d64f==NULL) {printf("Cant open %s!\n",d64name);return 1;}
        
        i=writed64(d64f);
        if(i!=0) {printf("Cant write %s!\n",d64name);return 1;}
        fclose(d64f);
                          
	return 0;
}

/******************************************/
int alloc(int t,int s)
{
 //we doublecheck if the sector is really free
 if(!isfree(t,s)) return -1;
 if(d64image[18][0][t*4]==0) return -1;
 d64image[18][0][t*4+1+s/8]=d64image[18][0][t*4+1+s/8] & 255-(1<<(s&7));
 d64image[18][0][t*4]--;
 return 0;
}

void freets(int t, int s)
{
 d64image[18][0][t*4+1+s/8]=d64image[18][0][t*4+1+s/8] | (1<<(s&7));
}

/******************************************/
int isfree(int t,int s)
{
  int r;
  
  r=d64image[18][0][t*4+1+s/8] & 1<<(s&7);
  if(debug)
  {  
   printf("Track %i Sector %i is ",t,s);
   if(r) printf("free\n");
   else printf("allocated\n");
  }
  return r;
}

/******************************************/
int writed64(FILE * d64f)
{
 int t,s,b;
 int i;
 for(t=1;t<36;t++)
 {
  for(s=0;s<=spt[t];s++)
  {
    //fprintf(stderr,"Reading track %02i, sector %02i\r",t,s);
    for(b=0;b<256;b++)
    {
      i=fputc(d64image[t][s][b],d64f);
      if(i==EOF) return -1;
    }
  }
 }
 //fprintf(stderr,"\n");
 return 0;
}

/******************************************/
void setParams(int argc, char** argv) {
	
	d64name=argv[1];
	if(argc<2) 
	{
	 printf("%s",vers+6);
	 printf("Usage: %s filename.d64 title,id\n",argv[0]);
	 exit(1);
	}
        if(argc<3) title=empty;	
        else title=argv[2];	
	return;
}
