/* printbam

  Write files into an already existing d64-archive

  -lpopt
 
*/	

char *vers="\0$VER: printbam 1.0 27-Dec-03\n";
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*prototypes*/
void setParams(int argc, char** argv);
int readd64(FILE * d64f);
int isfree(int track,int sector);

/*global vars*/

char * d64name;
FILE * d64f;

unsigned char d64image[36][21][256];

int spt[36]={ 0,
/* 1-17 */   20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,
/*18-24 */   18,18,18,18,18,18,18,
/*25-30 */   17,17,17,17,17,17,
/*31-35 */   16,16,16,16,16
            };
                           
int debug;

int main(int argc, char ** argv)
{
	int i,j;
	int t,s;
	int total;
	
	setParams(argc,argv);
        if(d64name!=NULL) d64f=fopen(d64name,"rb");
        if(d64f==NULL) {printf("Cant open %s!\n",d64name);return 1;}
        
        i=readd64(d64f);
        if(i!=0) {printf("Cant read %s!\n",d64name);return 1;}
        fclose(d64f);

        total=0;
        printf("             1         2\tFree\n");
        printf("   012345678901234567890\tBlocks\n");
        for(t=1;t<36;t++)
        {
         printf("%02i ",t);
         i=0;
         for(s=0;s<=spt[t];s++)
         {
           if(isfree(t,s))
           {
            printf("0");
            i++;
           }
           else
           {
            printf("1");
           }
         }
         j=d64image[18][0][t*4];
         printf("     \t%02i",j);
         if(i!=j) printf(" ERROR: blockcount=%i",i);
         total+=j;
         printf("\n");
        }
        printf("w/o Track 18:%i Blocks free.\t%i\n",total-(spt[18]-1),total);        
	return 0;
}

/******************************************/
int isfree(int t,int s)
{
  int r;
  
  r=d64image[18][0][t*4+1+s/8] & 1<<(s&7);
  if(debug)
  {  
   printf("Track %i Sector %i is ",t,s);
   if(r) printf("free\n");
   else printf("allocated\n");
  }
  return r;
}

/******************************************/
int readd64(FILE * d64f)
{
 int t,s,b;
 int i;
 for(t=1;t<36;t++)
 {
  for(s=0;s<=spt[t];s++)
  {
    //fprintf(stderr,"Reading track %02i, sector %02i\r",t,s);
    for(b=0;b<256;b++)
    {
      i=fgetc(d64f);
      if(i==EOF) return -1;
      d64image[t][s][b]=i;
    }
  }
 }
 //fprintf(stderr,"\n");
 return 0;
}

/******************************************/
void setParams(int argc, char** argv) {
	char c;

	/* defaults */
	debug=0;
                        					
	d64name=argv[1];
	
        return;
}
