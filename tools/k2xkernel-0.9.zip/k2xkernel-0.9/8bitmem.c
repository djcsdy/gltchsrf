/* 8bitmem.c */
/* Utility function for handling with 8 bit memory */
/* 
  V1.3 AK reading last byte upto $FFFF
  V1.2 AK prototypes + writela added 
  V1.1 AK hex2i repaired
	  error if $10000 reached
*/
/* TODO:
  functions lobyte,hibyte
*/

#include <stdio.h>
#include <stdlib.h>

#include "8bitmem.h"

int hex2i(char * hexstr) {
	int tmp,addr;
	if (hexstr[0]=='$')
	  tmp=sscanf(hexstr,"$%x",&addr);
	else if (hexstr[0]=='0' && hexstr[1]=='x')
	       tmp=sscanf(hexstr,"0x%x",&addr);
	     else
	       tmp=sscanf(hexstr,"%d",&addr);
		
	if(tmp<1) {
	  fprintf(stderr,"Error-Not a Number:%s\n",hexstr);
	  return -1;
	}
	if(addr<0||addr>0xFFFF) {
	  fprintf(stderr,"Error-Not a valid Number:%i\n",addr);
	  return -1;
	}
	return addr;
}		

void * initmem()
{        
	mem=malloc(65536);
	if(mem==NULL) {
		return mem;
	}
	memset(mem,0,65536);
	pc_start=65535;pc_end=0;
	return mem;
}

void exitmem()
{
	free(mem);
}

int writemem(FILE * outf)
{
	word pc;
	fputc( ( (char*) (&pc_start) )[0] ,outf);
	fputc( ( (char*) (&pc_start) )[1] ,outf);
	for(pc=pc_start;pc<pc_end;pc++) {
		fputc(mem[pc],outf);		
	}
	return 0;
}

int readmem(FILE * inf)
{
	int pc;
	int tmp;
	int ret=0;
	
	tmp=readla(inf);
	if(tmp==-1) {
		return -1;
	}
	pc=tmp;
		
	if(pc<pc_start) pc_start=pc;
		
	while(1)
	{
		tmp=fgetc(inf);
		if(tmp==EOF) break;
		mem[pc]=tmp;
// Checking of overlapping objects:
//		if(dnc[pc]==0) ret++;
//		dnc[pc]=0;
		pc++;
		if(pc==0x10001) return -1; //ZY
	}
	if(pc>pc_end) pc_end=pc;
	return ret;
}		

int readla(FILE * handle)
{
	unsigned char wl,wh;
	unsigned int pc;
	
	wl=fgetc(handle);
	wh=fgetc(handle);

	pc=wl+256*wh;
	
	return pc;
}

int writela(word start,FILE *handle){
     if(start!=0)
     {
	byte l,h;
	l=(byte) (start & 0xFF);
	h=(byte) (start >> 8);
	if(fputc(l,handle)==EOF) return EOF;
	if(fputc(h,handle)==EOF) return EOF;
     }
     return 0;
}




