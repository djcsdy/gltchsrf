#ifndef BISON_DNC_TAB_H
# define BISON_DNC_TAB_H

# ifndef YYSTYPE
#  define YYSTYPE int
#  define YYSTYPE_IS_TRIVIAL 1
# endif
# define	TOK_VALUE	257
# define	TOK_TO	258
# define	TOK_SPEC	259
# define	TOK_NEWLINE	260


extern YYSTYPE yylval;

#endif /* not BISON_DNC_TAB_H */
