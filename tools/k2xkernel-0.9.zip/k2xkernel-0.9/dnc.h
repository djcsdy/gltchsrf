/* DNC.H */
/* Header for DNC.LIB */
/* Utility-function for handling with do_not_care values */

#ifndef DNC_H
#define DNC_H
#include <stdio.h>

typedef unsigned int value;
//typedef unsigned char byte;

/*prototypes*/
int DNC_Init(int fill);
void DNC_Exit();
int DNC_Write(value Start,value End);
int DNC_Read();
int DNC_SetFile(FILE *);
#ifdef ACME
int DNC_PO_dnc();
#else
void ThrowError(char *);
#endif
/*global vars*/
unsigned char *DNCBuffer;
FILE * DNCfile;
extern FILE * yyin;

#endif


