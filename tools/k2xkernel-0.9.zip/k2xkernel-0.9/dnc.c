/* DNC.LIB */
/* Utility-functions to handle with for do_not_care values */

/*
   V1.1 "acme-project"
   	01.10.2002 ZY Without 8bitmem, uses acme types
   V1.0 
   	15.09.2002 AK Last byte standing Bug removed

  TODO: We changed from 0,!=0 to 0..255
  	0->no dnc bits
  	255-> all bits dnc
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dnc.h"
#include "dnc.yy.c"
#include "dnc.tab.c"

/* #include "8bitmem.h" */

char Exception_No2ndDncfile[] = "DNC file already chosen.";
char Exception_NoDncmemory[] = "Can't get memory for DNC.";
char Exception_DncWriteProtect[] = "Can't write to DNC file.";

int DNC_Init(int fill)
{
  DNCBuffer=malloc(65536);
  if(DNCBuffer==NULL) {ThrowError(Exception_NoDncmemory);return DNCBuffer;}
  memset(DNCBuffer,fill,65536);
  return DNCBuffer;
}

void DNC_Exit()
{
  free(DNCBuffer);
}

// TODO: ERRORCHECKING
int DNC_Write(value Start, value End)
{
	value pc;
	value from,to;
	int inside;
#ifdef DEBUG	
	fprintf(stderr,"Here come the DNC!\n");	
#endif
	inside=0;
	for(pc=Start;pc<=End;pc++) {
		if(DNCBuffer[pc]==255 && inside==0) {
		  from=pc;inside=1;
		}
		if(DNCBuffer[pc]!=255 && inside==1) {
		  to=pc-1;
		  if(from==to) fprintf(DNCfile,"$%04X\n",from);
		  if(to>from) fprintf(DNCfile,"$%04X - $%04X\n",from,to);
		  inside=0;
		}
		if(DNCBuffer[pc]>0 && DNCBuffer[pc]<255) {
		  fprintf(DNCfile,"$%04X:$%02X\n",pc,DNCBuffer[pc]);
		}
				
	};
	return 0;
}

// TODO: ERRORCHECKING
int DNC_Read()
{
	yyin=DNCfile;
	yyparse();	
	return 0;
}

/*
 * Select dnc file
 */
int DNC_SetFile(FILE * filehandle) {
  DNCfile=filehandle;
}

#ifdef ACME
int DNC_PO_dnc() {
  byte Filename[LNPMAX + 1];/* file name */

  if((Pass_Flags & PASS_ISFIRST)) {
    if(DNCfile) {
      ThrowError(Exception_No2ndDncfile);
    } else {
      if(Stream_ReadFilename(Filename, LNPMAX, FALSE)) {
        if((DNCfile = File_OpenFile(Filename, FILE_READTEXT))) {
          PLATFORM_SETFILETYPE(Filename, FILETYPE_TEXT);
          DNC_read();
          File_CloseFile(DNCfile);
        }
	if((DNCfile = File_OpenFile(Filename, FILE_WRITETEXT))) {
	  PLATFORM_SETFILETYPE(Filename,FILETYPE_TEXT);
	}
	else {
	  ThrowError(Exception_DncWriteProtect);
	}
        /* If we cant open it, we need not read dnc! */
        return(ENSURE_EOL);
      }
    }
  }
  return(SKIP_REST);
}
#else
void ThrowError(char * message) {
  fprintf(stderr,message);
}
#endif

