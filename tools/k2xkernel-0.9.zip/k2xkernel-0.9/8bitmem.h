/* 8bitmem.h */

#ifndef EIGHT_BIT_MEM_H
#define EIGHT_BIT_MEM_H

/* typedefs */
typedef unsigned char byte;
typedef unsigned short word;

/* prototypes */

int readla(FILE * handle);
int writela(word start, FILE *handle);

void * initmem();
int writemem(FILE *outf);
int readmem(FILE *inf);

int hex2i(char * hexstr);

/* global vars */
byte *mem;
word pc_start;//,pc_end;
int pc_end;
//unsigned int pc_start,pc_end;

#endif
